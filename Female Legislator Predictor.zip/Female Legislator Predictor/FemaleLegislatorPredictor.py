# Importing the necessary libraries.
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import os
from datetime import datetime as dt
from statsmodels.tsa.arima.model import ARIMA
import warnings

# The necessary functions for this project.
def file_path():
    print("Hello and welcome to the predictor program for future legislators in Congress:") # This code allows the user to input their file path for the provided JSON file.
    print("\n")
    
    print("format = C:/Folder Name/etc")

    try:
        dr = input("Please enter your file path for the JSON file (NO SPACES PLEASE UNLESS THERE ARE SPACES IN THE FILE NAME!):")

    except ValueError:
        print("\n")
        print("Sorry, but that is not a valid file path or the location is wrong. Please try again.")
        print("\n")
        file_path()

    try:
        os.chdir(dr)

    except (ValueError, FileNotFoundError, OSError):
        print("\n")
        print("Sorry, but that is not a valid file path or the location is wrong. Please try again.")
        print("\n")
        file_path()

def index_update(index, dictionary, key):
    temp_list = dictionary[key]
    temp_list[index] += 1
    return temp_list

def di_to_list(di, k):
    temp = []
    
    for key, value in di.items():
        temp.append(value[k])
    
    return temp

def year_count(main_df, year_df):
    count = {}
    years = year_df['Year'].tolist()
    years_dict = {}
    for y in years:
        years_dict[y] = [0, 0, 0]
    
    start = main_df['Start'].tolist()
    end = main_df['End'].tolist()
    gender_iter = main_df['Gender'].tolist()
    
    for s,e,g in zip(start, end, gender_iter):
        temp = range(s, e)
        temp_list = list(temp)
        
        
        for y in range(len(temp_list)):
            years_dict[temp_list[y]] = index_update(0, years_dict, temp_list[y])
            #print(temp_list[y])
            
            if g == "M":
                years_dict[temp_list[y]] = index_update(1, years_dict, temp_list[y])
            else:
                 years_dict[temp_list[y]] = index_update(2, years_dict, temp_list[y])
            
            if temp_list[y] == temp_list[-1]:
                last_year = temp_list[y] + 1
                years_dict[last_year] = index_update(0, years_dict, last_year)
                
                if g == "M":
                    years_dict[last_year] = index_update(1, years_dict, last_year)
                else:
                    years_dict[last_year] = index_update(2, years_dict, last_year)
                
        #print(temp_list)
    #print(years_dict)
    total = di_to_list(years_dict, 0)
    male = di_to_list(years_dict, 1)
    female = di_to_list(years_dict, 2)
    data = {"Year" : years, "Total" : total, "Male" : male, "Female" : female}
    return pd.DataFrame(data)

def future_years(df, year):
    temp_range = range(max(df['Year'])+1, year+1, 1)
    temp_list = list(temp_range)
    total = []
    male = []
    female = []
    
    for i in temp_list:
        total.append(0)
        male.append(0)
        female.append(0)
    
    temp_list = pd.Series(temp_list)
    total = pd.Series(total)
    male = pd.Series(male)
    female = pd.Series(female)
    
    return {'Year' : temp_list, 'Total' : total, 'Male' : male, 'Female' : female}

def df_splitter(df):
    splitter = int(round((30/100) * len(df), 1))
    separator = len(df) - splitter
    dte = df.index[separator].strftime("%Y")
    
    train = df[df.index <= pd.to_datetime(dte, format="%Y")]
    test = df[df.index > pd.to_datetime(dte, format="%Y")]
    
    return train, test

# Main Function.
def main():
    warnings.filterwarnings('ignore')
    
    try:
        df = pd.read_json('legislators-historical.json') # Reading the JSON file.

    except ValueError:
        print("\n")
        print("Sorry, but that is not a valid file path or the location is wrong. Please try again.")
        print("\n")
        file_path()
        main()

    gender = []
    for key, value in df['bio'].items():
        gender.append(value.get('gender'))

    full_name = []
    for key, value in df['name'].items():
        full_name.append(value.get('first') + " " + value.get('last'))

    terms = []
    for key, value in df['terms'].items():
        terms.append(value)

    data = []
    for (name, gndr, term) in zip(full_name, gender, terms):
        for t in term:
            temp = []
            temp.append(name)
            temp.append(gndr)
            temp.append(t)
            data.append(temp)

    df_new = pd.DataFrame(data, columns=['Name', 'Gender', 'Terms']) # New dataframe is created with Name, Gender and Terms columns.

    term_type = []
    for key, value in df_new['Terms'].items():
        term_type.append(value.get('type'))

    start = []
    for key, value in df_new['Terms'].items():
        start.append(value.get('start'))

    end = []
    for key, value in df_new['Terms'].items():
        end.append(value.get('end'))

    name = df_new['Name'].tolist()
    gender = df_new['Gender'].tolist()

    data = {"Name" : name, "Gender" : gender, "Type" : term_type, "Start" : start, "End" : end}
    df_fixed = pd.DataFrame(data) # New dataframe created with Type, Start and End getting separated into their own columns.

    df_fixed["Start"] = df_fixed["Start"].astype("datetime64")
    df_fixed["End"] = df_fixed["End"].astype("datetime64")

    df_fixed["Start"] = df_fixed["Start"].dt.year
    df_fixed["End"] = df_fixed["End"].dt.year

    df_fixed["Start"] = df_fixed["Start"].astype(str)
    df_fixed["End"] = df_fixed["End"].astype(str)
    df_fixed["Start"] = df_fixed["Start"].str.replace('\D', '').astype(int)
    df_fixed["End"] = df_fixed["End"].str.replace('\D', '').astype(int) # Start and End columns now converted into year only.

    count_range = [*range(1789, 2023, 1)]
    #print(count_range)
    count_data = {'Year' : count_range}
    df_count = pd.DataFrame(count_data)
    df_count = df_count.sort_values(by='Year', ascending=True)
    df_count.head() # Creating a new dataframe with only the years.

    df_count = year_count(df_fixed, df_count) # Getting the count of the total, male and female legislators in office for each year from 1789 to 2022.
    df_count = df_count.drop(233) # Dropped the 2022 column as the year just started and there was only 1 male shown for the year, which could lead to inaccuracies later on.

    print("\n")
    try:
        year_pred = int(input("Now please select the year that you want to predict (MUST BE IN YYYY FORMAT FROM 1900 OR ABOVE!):"))

    except ValueError:
        print("\n")
        print("Sorry, but your date is invalid. Please try again.")
        print("\n")
        main()

    if year_pred > max(df_count['Year']): # Separates the dataframe from to the predicted value.
        future = future_years(df_count, year_pred)
        future_df = pd.DataFrame(future)
        df_count = pd.concat([df_count, future_df], ignore_index=True, axis=0)
        
    elif year_pred < max(df_count['Year']):
        df_count = df_count.loc[df_count['Year'] <= year_pred]
        
    else:
        pass

    try:
        years = df_count['Year'].tolist()
        years_str = [str(i) for i in years]

        for y in range(len(years_str)):
            years_str[y] = dt.strptime(years_str[y], "%Y")

        df_count.index = pd.to_datetime(df_count['Year'], format="%Y")
        del df_count['Year'] # Converting the year column into an index of type datetime.

    except:
        print("\n")
        print("Sorry, but your date is way above range. Please try again.")
        print("\n")
        main()

    if year_pred < 1900:
        print("\n")
        print("Sorry, but the prediction must begin at 1900. Try again:")
        print("\n")
        main()

    else:
        print("Prediction incoming. Please wait.")

        train, test = df_splitter(df_count) # Splitting the data into training and testing sets with a test size of 30%.

        y_female = train['Female']
        ARIMA_mod = ARIMA(y_female, order=(2,2,2)) # Using the ARIMA algorithm to make the predictions.
        ARIMA_mod = ARIMA_mod.fit()

        y_female_pred = ARIMA_mod.get_forecast(len(test.index))
        y_female_pred_df = y_female_pred.conf_int(alpha=0.05)
        y_female_pred_df["Predictions"] = ARIMA_mod.predict(start=y_female_pred_df.index[0],
                                                    end=y_female_pred_df.index[-1])
        y_female_pred_df.index = test.index
        y_pred_out = y_female_pred_df["Predictions"]

    print("\n")
    print("The predicted amount of female legislators for ", year_pred, " is: ", int(round(y_pred_out.iloc[-1], 1)))

    print("\n")
    viz = input("Do you want a visualization of the prediction(Y/N NO SPACES PLEASE!):") # Checking if the user wants a graphical visualization of the prediction.

    if viz == 'Y':
        plt.plot(y_pred_out, color='green', label='Predictions')
        plt.title("The Predicted Values")
        plt.xlabel("Years")
        plt.ylabel("Amount of Female Legislators")
        plt.legend()
        plt.show()

    elif viz == 'N':
        print("That's fine.")

    else:
        print("I'll take that as a no.")

    
    reset = input("Do you want to try out another prediction (Y/N NO SPACES PLEASE!):") # Checking if the user wants to try out another prediction.

    if reset == 'Y':
        print('\n')
        print('\n')
        main()

    elif reset == 'N':
        print("Thanks for trying out the predictor.")
        quit()

    else:
        print("I'll take that as a no, anyways, thanks for trying out the predictor.")
        quit()
    
# Driver Code
file_path()
main()
